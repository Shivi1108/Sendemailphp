function validateForm() {
  let fname = document.forms["emailTemplate"]["fname"].value;
  let lname = document.forms["emailTemplate"]["lname"].value;
  let email = document.forms["emailTemplate"]["mail"].value;
  let sub = document.forms["emailTemplate"]["sub"].value;
  let msg = document.forms["emailTemplate"]["msg"].value;
  if (fname == "") {
    alert("Please enter firstname");
    return false;
  }
    if (lname == "") {
    alert("Please enter lastname");
    return false;
  }

   if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(emailTemplate.mail.value))
  {
    
  }
  else
  {
   alert("invalid email format");
   return false;
  }
  
    if (sub == "") {
    alert("Email subject can not be empty");
    return false;
  }
    if (sub == "") {
    alert("Email body can not be empty");
    return false;
  }
}